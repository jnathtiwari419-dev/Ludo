const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, app: "NV STUDIOS Ludo" }));

const rooms = new Map();
const waiting = [];

function makeCode() {
  return crypto.randomBytes(3).toString("hex").toUpperCase();
}
function publicRoom(room) {
  return {
    code: room.code,
    players: room.players.map(p => ({ id: p.id, name: p.name, color: p.color })),
    maxPlayers: room.maxPlayers,
    status: room.status,
    turn: room.turn,
    dice: room.dice,
    lastAction: room.lastAction
  };
}
function emitRoom(room) {
  io.to(room.code).emit("room:update", publicRoom(room));
}
function createRoom(host, maxPlayers = 4) {
  let code = makeCode();
  while (rooms.has(code)) code = makeCode();
  const room = {
    code, maxPlayers: Math.max(2, Math.min(4, Number(maxPlayers) || 4)),
    players: [{ id: host.id, name: host.name || "Player", color: "red" }],
    status: "waiting", turn: 0, dice: null, lastAction: "Room created"
  };
  rooms.set(code, room);
  host.join(code);
  host.data.roomCode = code;
  return room;
}
function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code || !rooms.has(code)) return;
  const room = rooms.get(code);
  room.players = room.players.filter(p => p.id !== socket.id);
  socket.leave(code);
  socket.data.roomCode = null;
  if (!room.players.length) rooms.delete(code);
  else {
    room.turn = room.turn % room.players.length;
    room.lastAction = "A player left the room";
    if (room.status === "playing" && room.players.length < 2) room.status = "waiting";
    emitRoom(room);
  }
}
io.on("connection", socket => {
  socket.on("room:create", ({ name, maxPlayers } = {}, ack = () => {}) => {
    leaveRoom(socket);
    const room = createRoom({ ...socket, name: String(name || "Player").slice(0, 18) }, maxPlayers);
    emitRoom(room);
    ack({ ok: true, room: publicRoom(room) });
  });

  socket.on("room:join", ({ code, name } = {}, ack = () => {}) => {
    const room = rooms.get(String(code || "").trim().toUpperCase());
    if (!room) return ack({ ok: false, error: "Room not found. Check the code and try again." });
    if (room.players.length >= room.maxPlayers) return ack({ ok: false, error: "This room is full." });
    if (room.status === "playing") return ack({ ok: false, error: "This game has already started." });
    leaveRoom(socket);
    const colors = ["red", "blue", "green", "yellow"];
    room.players.push({ id: socket.id, name: String(name || "Player").slice(0, 18), color: colors[room.players.length] });
    socket.join(room.code);
    socket.data.roomCode = room.code;
    room.lastAction = `${String(name || "A player").slice(0, 18)} joined`;
    emitRoom(room);
    ack({ ok: true, room: publicRoom(room) });
  });

  socket.on("matchmaking:join", ({ name } = {}, ack = () => {}) => {
    leaveRoom(socket);
    const open = [...rooms.values()].find(r => r.status === "waiting" && r.players.length < r.maxPlayers);
    if (open) {
      const colors = ["red", "blue", "green", "yellow"];
      open.players.push({ id: socket.id, name: String(name || "Player").slice(0, 18), color: colors[open.players.length] });
      socket.join(open.code);
      socket.data.roomCode = open.code;
      open.lastAction = `${String(name || "A player").slice(0, 18)} joined`;
      emitRoom(open);
      ack({ ok: true, room: publicRoom(open) });
    } else {
      const room = createRoom({ ...socket, name: String(name || "Player").slice(0, 18) }, 4);
      waiting.push(room.code);
      emitRoom(room);
      ack({ ok: true, room: publicRoom(room) });
    }
  });

  socket.on("game:start", (_data, ack = () => {}) => {
    const room = rooms.get(socket.data.roomCode);
    if (!room) return ack({ ok: false, error: "Join a room first." });
    if (room.players.length < 2) return ack({ ok: false, error: "At least two players are needed." });
    room.status = "playing";
    room.turn = 0;
    room.dice = null;
    room.lastAction = "Game started";
    emitRoom(room);
    ack({ ok: true });
  });

  socket.on("game:roll", (_data, ack = () => {}) => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.status !== "playing") return ack({ ok: false, error: "The game is not running." });
    if (room.players[room.turn]?.id !== socket.id) return ack({ ok: false, error: "Wait for your turn." });
    room.dice = crypto.randomInt(1, 7);
    room.lastAction = `${room.players[room.turn].name} rolled ${room.dice}`;
    emitRoom(room);
    ack({ ok: true, dice: room.dice });
  });

  socket.on("game:pass", (_data, ack = () => {}) => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.status !== "playing") return ack({ ok: false, error: "The game is not running." });
    if (room.players[room.turn]?.id !== socket.id) return ack({ ok: false, error: "Wait for your turn." });
    if (room.dice === null) return ack({ ok: false, error: "Roll the dice first." });
    const rolledSix = room.dice === 6;
    room.dice = null;
    if (!rolledSix) room.turn = (room.turn + 1) % room.players.length;
    room.lastAction = rolledSix ? "You rolled a six — take another turn!" : "Turn passed";
    emitRoom(room);
    ack({ ok: true });
  });

  socket.on("room:leave", () => leaveRoom(socket));
  socket.on("disconnect", () => leaveRoom(socket));
});

server.listen(PORT, () => console.log(`NV STUDIOS Ludo running on port ${PORT}`));