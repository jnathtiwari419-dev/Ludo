# NV STUDIOS — Online Ludo

Branding: **NV STUDIOS**  
Production line: **NISHA VISHESH COOPERATIVE**

## Included
- Responsive dark navy and gold branded interface
- Create private room and join by room code
- Random matchmaking into an open room
- Real-time lobby/player updates using Socket.IO
- Server-authoritative dice roll and turn hand-off demo
- Health endpoint at `/health`

## Run locally
1. Install Node.js 18 or newer.
2. Extract this ZIP.
3. Open a terminal in the extracted folder.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000` in your browser.

For testing with friends on different devices, deploy the Node app to a host that supports persistent Node.js processes and WebSockets. A static-only host (such as GitHub Pages) cannot run this multiplayer server.

## Important development note
This is a multiplayer lobby and turn/dice foundation, not yet a complete rules-compliant Ludo game. Token movement, home paths, safe squares, captures, six-to-release logic, exact finish rules, reconnect recovery, persistent accounts, moderation and anti-cheat still need implementation and testing before public production launch. The current board graphic is decorative.

## Suggested deployment
Use a Node.js hosting provider that supports WebSockets. Set the start command to `npm start`; the server reads the provider's `PORT` environment variable.

## Branding
The supplied project uses the requested production branding:
**NV STUDIOS**  
**NISHA VISHESH COOPERATIVE**
