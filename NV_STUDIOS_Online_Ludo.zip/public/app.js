const socket = io();
const $ = id => document.getElementById(id);
let currentRoom = null;
const colors = {red:"#e76c70",blue:"#6d9ce8",green:"#55bd91",yellow:"#edc85f"};

function name() { return $("playerName").value.trim().slice(0,18) || "Player"; }
function status(message, bad=false) { $("status").textContent = message; $("status").style.color = bad ? "#ff9292" : "#9aa6ba"; }
function showRoom(room) {
  currentRoom = room;
  $("roomPanel").classList.remove("hidden");
  $("roomTitle").textContent = room.status === "playing" ? "Game in progress" : "Room lobby";
  $("roomCodeDisplay").textContent = room.code;
  $("players").innerHTML = room.players.map((p,i)=>`<div class="player-chip"><b style="color:${colors[p.color] || "#fff"}">● ${escapeHtml(p.name)}</b><span>${i===0?"Host":"Player"}</span></div>`).join("");
  $("gameStatus").textContent = `${room.lastAction || "Waiting for players"} · ${room.players.length}/${room.maxPlayers} players`;
  $("startBtn").disabled = room.players.length < 2 || room.status === "playing";
  $("rollBtn").disabled = room.status !== "playing" || room.players[room.turn]?.id !== socket.id || room.dice !== null;
  $("passBtn").disabled = room.status !== "playing" || room.players[room.turn]?.id !== socket.id || room.dice === null;
  $("dice").textContent = room.dice || "—";
  if (room.status === "playing") {
    $("gameStatus").textContent = `Turn: ${room.players[room.turn]?.name || "—"} · ${room.lastAction || ""}`;
  }
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function handleAck(result) {
  if (!result?.ok) { status(result?.error || "Something went wrong.", true); return; }
  status("Connected. Have fun!");
  if (result.room) showRoom(result.room);
}

$("createBtn").onclick = () => socket.emit("room:create", {name:name(), maxPlayers:4}, handleAck);
$("joinBtn").onclick = () => socket.emit("room:join", {name:name(), code:$("roomCode").value}, handleAck);
$("randomBtn").onclick = () => socket.emit("matchmaking:join", {name:name()}, handleAck);
$("startBtn").onclick = () => socket.emit("game:start", {}, result => { if(!result.ok) status(result.error,true); });
$("rollBtn").onclick = () => socket.emit("game:roll", {}, result => { if(!result.ok) status(result.error,true); });
$("passBtn").onclick = () => socket.emit("game:pass", {}, result => { if(!result.ok) status(result.error,true); });
$("leaveBtn").onclick = () => { socket.emit("room:leave"); currentRoom=null; $("roomPanel").classList.add("hidden"); status("You left the room."); };
$("copyBtn").onclick = async () => { if(!currentRoom)return; try { await navigator.clipboard.writeText(currentRoom.code); $("copyBtn").textContent="Copied!"; setTimeout(()=>$("copyBtn").textContent="Copy code",1300); } catch { status("Room code: "+currentRoom.code); } };
socket.on("connect",()=>status("Connected to NV STUDIOS game server."));
socket.on("disconnect",()=>status("Connection lost. Reconnecting…",true));
socket.on("room:update",showRoom);
